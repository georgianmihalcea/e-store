<?php
	$db = array (
		"db_host" => 'localhost',
        "db_user" => 'root',
        "db_pass" => 'smekerie',
        "db_name" => 'project1'
	);
?>