<!DOCTYPE html>
<html>
<head>
	<style> @import url('https://fonts.googleapis.com/css2?family=Open+Sans&display=swap'); </style>

	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Open+Sans&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="http://localhost/project/css/div.css">
	<link rel="stylesheet" href="http://localhost/project/css/id.css">
	<link rel="shortcut icon" type="image/x-icon" href="favicon.ico">
	<link rel="stylesheet" href="http://localhost/project/css/fontawesome/all.css">
	<script src="https://code.jquery.com/jquery-3.6.3.min.js" integrity="sha256-pvPw+upLPUjgMXY0G+8O0xUf+/Im1MZjXxxgOcBQBXU=" crossorigin="anonymous"></script>

		<title>metamagz.ro | Autentificare</title>
		<meta name="description" content="metamagz.ro | Cele mai bune produse, la cele mai accesibile preturi, intra acum!">
		
</head>

<body>
	<div class="wrapper text-center">
	<header>
		
		<div class="logo"><a href="http://localhost/project/index.html"> <img src="meta.png" alt="metamagz.ro" width="100px" height="90px"></a></div>
			<div class="search"><form><input type="text" placeholder="Cautare.."></form></div>
				<div class="shop hovl"><a href="cos-cumparaturi.html"><i class="fa fa-shopping-cart" style="font-size:25px;color:black"></i><span class="dspnone">&nbspCosul meu</span></a></div>
		<div class="login hovl"><a href="login.html"><i class="fa fa-user" style="font-size:25px;color:black"></i><span class="dspnone">&nbspLog in</span></a></div>
		
	<hr>
			
		
	<nav>
		<div class="navbar flex-menu">
			<a href="http://localhost/project/index.html"><i class="fa fa-home"></i><b>&nbspHOME</b></a>
				<div class="dropdown">		
					<button class="dropbtn">
						<strong><i class="fa-solid fa-list-ul"></i></i>&nbspBRANDURI</strong>
					</button>	
					<div class="dropdown-content hov">
						<a href="armani.html"><strong>Armani Exchange</strong></a>
						<a href="diesel.html"><strong>Diesel</strong></a>
						<a href="boss.html"><strong>Hugo Boss</strong></a>
					</div>	
				</div>
				<div class="dropdown">
					<button class="dropbtn">
						<strong><i class="fa-solid fa-list-ul"></i></i>&nbspGAMA DE LUX</strong>
					</button>
					<div class="dropdown-content2 hov">
						<a href="tissot.html"><strong>Tissot</strong></a>
					</div>
				</div>	
			<a href="despre.html"><strong>&nbspDESPRE NOI</strong></a>
			<a href="testimoniale.html"><strong>&nbspTESTIMONIALE</strong></a>
			<a href="contact.html"><strong>&nbspCONTACT</strong></a>
		</div>	
	<hr>
		
	</nav>